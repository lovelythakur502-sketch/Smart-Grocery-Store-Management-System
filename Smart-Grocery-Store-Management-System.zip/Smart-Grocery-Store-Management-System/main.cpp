#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <iomanip>
#include <string>
#include <limits>
using namespace std;

// Template class for storing different product types.
template <typename T>
class Product {
public:
    T id;
    string name;
    double price;
    int stock;

    Product(T productId, string productName, double productPrice, int quantity)
        : id(productId), name(productName), price(productPrice), stock(quantity) {}
};

class GroceryStore {
private:
    vector<Product<int>> products;
    queue<map<int, int>> checkoutQueue;

public:
    void addProduct() {
        int id, stock;
        string name;
        double price;

        cout << "\nEnter Product ID: ";
        if (!(cin >> id)) return;

        for (const auto& product : products) {
            if (product.id == id) {
                cout << "Product ID already exists!\n";
                return;
            }
        }

        cout << "Enter Product Name: ";
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        getline(cin, name);

        cout << "Enter Price: ";
        if (!(cin >> price) || price <= 0) {
            cout << "Please enter a valid positive price.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }

        cout << "Enter Stock Quantity: ";
        if (!(cin >> stock) || stock < 0) {
            cout << "Please enter a valid non-negative quantity.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }

        products.emplace_back(id, name, price, stock);
        cout << "Product added successfully!\n";
    }

    void displayProducts() const {
        cout << "\n========== PRODUCT LIST ==========\n";
        cout << left << setw(10) << "ID"
             << setw(24) << "Name"
             << setw(12) << "Price"
             << "Stock\n";

        if (products.empty()) {
            cout << "No products available.\n";
            return;
        }

        for (const auto& product : products) {
            cout << left << setw(10) << product.id
                 << setw(24) << product.name
                 << setw(12) << fixed << setprecision(2) << product.price
                 << product.stock << '\n';
        }
    }

    void searchProduct() const {
        int id;
        cout << "\nEnter Product ID: ";
        if (!(cin >> id)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input.\n";
            return;
        }

        for (const auto& product : products) {
            if (product.id == id) {
                cout << "\nProduct found!\n"
                     << "Name: " << product.name << '\n'
                     << "Price: Rs. " << fixed << setprecision(2) << product.price << '\n'
                     << "Stock: " << product.stock << '\n';
                return;
            }
        }
        cout << "Product not found.\n";
    }

    void customerPurchase() {
        map<int, int> cart;
        int id, quantity;

        if (products.empty()) {
            cout << "No products are available for purchase.\n";
            return;
        }

        displayProducts();
        cout << "\nEnter 0 as Product ID to finish.\n";

        while (true) {
            cout << "\nEnter Product ID: ";
            if (!(cin >> id)) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input. Try again.\n";
                continue;
            }
            if (id == 0) break;

            cout << "Enter Quantity: ";
            if (!(cin >> quantity) || quantity <= 0) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Enter a valid positive quantity.\n";
                continue;
            }

            bool found = false;
            for (const auto& product : products) {
                if (product.id == id) {
                    found = true;
                    if (product.stock >= cart[id] + quantity) {
                        cart[id] += quantity;
                        cout << "Added to cart.\n";
                    } else {
                        cout << "Insufficient stock. Available: "
                             << product.stock - cart[id] << '\n';
                    }
                    break;
                }
            }
            if (!found) cout << "Invalid Product ID.\n";
        }

        if (!cart.empty()) {
            checkoutQueue.push(cart);
            cout << "Customer added to the checkout queue.\n";
        } else {
            cout << "Cart is empty; no checkout request was created.\n";
        }
    }

    void generateBill() {
        if (checkoutQueue.empty()) {
            cout << "\nNo customer is waiting in the checkout queue.\n";
            return;
        }

        const map<int, int> currentCart = checkoutQueue.front();

        // Validate the complete order before changing stock.
        for (const auto& item : currentCart) {
            bool found = false;
            for (const auto& product : products) {
                if (product.id == item.first) {
                    found = true;
                    if (product.stock < item.second) {
                        cout << "Bill cancelled: insufficient stock for "
                             << product.name << ".\n";
                        checkoutQueue.pop();
                        return;
                    }
                    break;
                }
            }
            if (!found) {
                cout << "Bill cancelled: a product is no longer available.\n";
                checkoutQueue.pop();
                return;
            }
        }

        checkoutQueue.pop();

        double subtotal = 0.0;
        cout << "\n===============================================\n";
        cout << "             SMART GROCERY STORE\n";
        cout << "                 CUSTOMER BILL\n";
        cout << "===============================================\n";
        cout << left << setw(22) << "Product"
             << right << setw(6) << "Qty"
             << setw(12) << "Price"
             << setw(12) << "Amount\n";

        for (const auto& item : currentCart) {
            for (auto& product : products) {
                if (product.id == item.first) {
                    double amount = product.price * item.second;
                    subtotal += amount;
                    cout << left << setw(22) << product.name
                         << right << setw(6) << item.second
                         << setw(12) << fixed << setprecision(2) << product.price
                         << setw(12) << amount << '\n';
                    product.stock -= item.second;
                    break;
                }
            }
        }

        // Demonstration rate only. Actual GST depends on product category.
        const double gstRate = 0.05;
        const double gst = subtotal * gstRate;
        const double grandTotal = subtotal + gst;

        cout << "-----------------------------------------------\n"
             << "Subtotal:                  Rs. " << fixed << setprecision(2) << subtotal << '\n'
             << "GST (illustrative 5%):     Rs. " << gst << '\n'
             << "Grand Total:               Rs. " << grandTotal << '\n'
             << "===============================================\n"
             << "             THANK YOU! VISIT AGAIN.\n";
    }
};

int main() {
    GroceryStore store;
    int choice;

    do {
        cout << "\n========== SMART GROCERY STORE ==========\n"
             << "1. Add Product\n"
             << "2. Display Products\n"
             << "3. Search Product\n"
             << "4. Customer Purchase\n"
             << "5. Generate Customer Bill\n"
             << "6. Exit\n"
             << "Enter your choice: ";

        if (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1: store.addProduct(); break;
            case 2: store.displayProducts(); break;
            case 3: store.searchProduct(); break;
            case 4: store.customerPurchase(); break;
            case 5: store.generateBill(); break;
            case 6: cout << "Thank you for using the system!\n"; break;
            default: cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 6);

    return 0;
}
