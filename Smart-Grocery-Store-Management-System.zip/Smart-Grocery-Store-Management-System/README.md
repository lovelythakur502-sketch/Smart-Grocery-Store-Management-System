# Smart Grocery Store Management System

A console-based grocery store management application developed in **C++17**. It demonstrates how common store operations—product management, stock checking, customer carts, checkout queues, and billing—can be implemented using C++ and the Standard Template Library (STL).

## Features

- Add grocery products with a unique Product ID
- Display the product catalogue and available stock
- Search for products by ID
- Add multiple products and quantities to a customer cart
- Queue customer checkout requests using `std::queue`
- Store cart item quantities using `std::map`
- Calculate subtotal, illustrative GST, and grand total
- Reduce inventory after a successful bill
- Validate quantities and stock before billing

## C++ Concepts Demonstrated

- Classes and objects
- Class templates
- `std::vector`
- `std::map`
- `std::queue`
- Functions and loops
- Input validation
- Object-oriented programming

## Requirements

- A C++ compiler that supports C++17 (GCC, Clang, or MSVC)
- Terminal or an IDE such as Visual Studio Code or Code::Blocks

## Compile and Run

### Linux / macOS

```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o grocery
./grocery
```

### Windows (MinGW)

```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o grocery.exe
grocery.exe
```

## How to Use

1. Select **Add Product** to enter a product ID, name, price, and stock quantity.
2. Select **Display Products** to view the catalogue.
3. Select **Search Product** to find an item by its ID.
4. Select **Customer Purchase** to build a customer's cart. Enter `0` as the Product ID when finished.
5. Select **Generate Customer Bill** to process the next customer in the checkout queue and print the bill.
6. Select **Exit** to close the application.

## GST Note

The program uses an illustrative 5% GST calculation for demonstration. Actual GST rates and tax treatment vary by product category and applicable rules. This sample is not a tax-compliance or production billing system.

## Current Limitations

- Product and sales data are held in memory and are lost when the program closes.
- The program uses a console interface.
- Customer details, authentication, and persistent database storage are not included.

## Future Enhancements

- Save and load product data using file handling or a database
- Admin login and customer profiles
- Product categories, discounts, and coupon codes
- Customer names and invoice numbers
- Daily and monthly sales reports
- GUI-based billing interface
- Product expiry-date tracking

## License

This project is provided for educational and learning purposes. Add a license file if you plan to distribute it under specific reuse terms.
